

function ch($ch='',$ob='')
{
	$(function(){
	      $($ch).on('change',function(){
 				if (document.getElementById($ob).disabled !== true) {
 					document.getElementById($ob).disabled = false;
 				}
 				document.getElementById($ob).disabled = true
	      });
   }); 
}


function secadd($add,$ob,$func)
{
	$(function(){
	      $($add).one('click',function(){
 				$($ob).append($func);
	      });
    }); 
}

function secdel($add,$ob)
{
	$(function(){
	      $($add).one('click',function(){
	      		$($ob).last().remove();
	      });
   }); 
}

function work()
{
	var add = '<div class="addwork" style="margin:20px 0px;"><div class="form-inline">';
	add += ' <label> Company Name </label><input class="form-control" type="text" name="worka[]">';
	add += ' <label> From </label><input  class="form-control" type="date" name="workb[]"> - ';
	add += ' <label> To </label><input  class="form-control" type="date" name="workc[]"></div>';
	add += '<div class="form-group">';
	add += '<label> Description </label><textarea  class="form-control"  name="workd[]"></textarea>';
	add += '</div></div>';
	return add;
}

function skills()
{
	var add = '<div class="vava" style="margin:20px 0px;"><div class="form-group">';
	add += ' <label> Skill Name </label><input class="form-control" type="text" name="skilla[]">';
	add += '<label> Description </label><textarea  class="form-control"  name="skillb[]"></textarea>';
	add += '</div></div>';
	return add;
}

function courses()
{
	var he = '<div class="aaa" style="margin:20px 0px;"><div class="form-inline">';
	he += ' <label> Course Place </label> <input class="form-control" type="text" name="coursea[]"> ';
	he += ' <label> From </label> <input  class="form-control" type="date" name="courseb[]">  ';
	he += ' <label> To </label> <input  class="form-control" type="date" name="coursec[]"></div> ';
	he += '<div class="form-group"><label>Dgree</label><input class="form-control" type="text" name="coursed[]"></div>';
	he += '<div class="form-group"><label>Description</label><textarea class="form-control"  name="coursef[]"></textarea></div>';
	he += '</div></div>';
	return he;
}

function education()
{
	var he = '<div class="educ" style="margin:20px 0px;"><div class="form-inline ">';
	he += ' <label> Education Place </label> <input class="form-control" type="text" name="edua[]"> ';
	he += ' <label> From </label> <input  class="form-control" type="date" name="edub[]">  ';
	he += ' <label> To </label> <input  class="form-control" type="date" name="educ[]"></div> ';
	he += '<div class="form-group"><label>Dgree</label><input class="form-control" type="text" name="edud[]"></div>';
	he += '<div class="form-group"><label>Description</label><textarea class="form-control"  name="eduf[]"></textarea></div>';
	he += '</div></div><br>';
	return he;
}