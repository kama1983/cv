<div class='form-group'>
 	 <h3 class='heading-h3'>Intersets</h3>
     <label>Intersets</label>
     <textarea class='tinymcstextarea form-control' id="Intersets" name="Intersets"><?php echo sess('Intersets'); ?></textarea> 
</div>   